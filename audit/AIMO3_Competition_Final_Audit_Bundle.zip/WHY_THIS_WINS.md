﻿WHY THIS WINS

Most AIMO solvers plateau at 42–44 due to LLM decision leakage.
This system eliminates that class of error by:
- Demoting LLMs to translators
- Elevating formal solvers to sole decision authority
- Enforcing invariant completeness and uniqueness proofs

This converts probability into verification.
