﻿COMPLIANCE ATTESTATION

This submission:
- Uses no internet access
- Uses no external datasets
- Uses no hidden files
- Uses no stochastic sampling
- Uses no LLM for decision-making
- Produces one integer per problem only

LLMs (if present) are translators only.
All final answers are produced by formal solvers.
