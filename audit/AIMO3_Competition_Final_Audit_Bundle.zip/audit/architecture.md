﻿Architecture Summary

- LLMs act as translators only
- Formal solvers produce all answers
- Z3 for integers, logic, optimization
- SymPy for algebra and geometry
- Brute force only when bounded
- Router is regex/keyword-based
- No manual intervention
