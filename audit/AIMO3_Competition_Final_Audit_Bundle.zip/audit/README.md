# AIMO-3 Formal Audit Package

This directory contains the formal audit protocol, devil�s advocate challenge rules, determinism guarantees, and verification expectations for the AIMO-3 submission.
