﻿SECURITY POSTURE

- No self-modifying code
- No file I/O affecting outputs
- No network calls
- Bounded resource usage
- Process-level timeouts enforced

Eval usage (if any) is restricted to parsed mathematical expressions only.
