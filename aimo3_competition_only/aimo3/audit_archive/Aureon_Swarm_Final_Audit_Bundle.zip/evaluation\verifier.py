def verify(answer):
    try:
        return answer is not None
    except:
        return False
