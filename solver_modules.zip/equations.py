﻿def solve_linear(a,b,c):
    # ax + b = c
    return (c-b)/a
